
import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


public class Main2014302580382 {

	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
		Document doc = null;
		FileWriter fileWrite;
		try {
			doc = Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Zha%20Quan%20Xing").get();
			String title = doc.title();
		
		Elements Content = doc.getElementsByTag("p");
		
		String con=Content.text();
		System.out.println(con);
		
		String regex1="[0-9]{3}-[0-9]{8}";  
        Matcher m=Pattern.compile(regex1).matcher(con);
//        System.out.println(m.find());
//        System.out.println(m.group());
        if(m.find()){
        	System.out.println(m.group());
        }
        String regex2="\\w+@(\\w+.)+[a-z]{2,3}";  
        Matcher n=Pattern.compile(regex2).matcher(con);
          //System.out.println(n.find());
          //System.out.println(n.group());
        if(n.find())  {
        	System.out.println(n.group());
        }
     FileWriter fileWriter=new FileWriter("Result.txt");
     fileWriter.write("��ϵ�绰"+m.group());
     fileWriter.write("����"+n.group());    
     fileWriter.flush();
     fileWriter.close();
      
		}
		catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}

}
     